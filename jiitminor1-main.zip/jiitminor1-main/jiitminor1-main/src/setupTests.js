// jest-dom adds custom Jest matchers for asserting on DOM nodes.
// These matchers allow for easier testing of DOM-related assertions, such as:
// expect(element).toHaveTextContent(/react/i)
// Learn more at: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';
